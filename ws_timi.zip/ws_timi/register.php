<?php
header("Access-Control-Allow-Origin: *");
$arr = null;
$conn = new mysqli("localhost", "root", "", "cats");
if ($conn->connect_error) {
    $arr = ["result" => "error", "message" => "unable to connect"];
}

extract($_POST);

$sql = "SELECT id FROM users where email = ? and username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $email, $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $arr = ["result" => "error", "message" => "Akun dengan email " . $email . " dan username " . $username . " sudah ada. Silahkan gunakan email dan username lain."];
} else {
    $sql1 = "SELECT id FROM users where email = ?";
    $stmt1 = $conn->prepare($sql1);
    $stmt1->bind_param("s", $email);
    $stmt1->execute();
    $result1 = $stmt1->get_result();

    if ($result1->num_rows > 0) {
        $arr = ["result" => "error", "message" => "Akun dengan email " . $email . " sudah ada. Silahkan gunakan email lain."];
    } else {
        $sql2 = "SELECT id FROM users where username = ?";
        $stmt2 = $conn->prepare($sql2);
        $stmt2->bind_param("s", $username);
        $stmt2->execute();
        $result2 = $stmt2->get_result();

        if ($result2->num_rows > 0) {
            $arr = ["result" => "error", "message" => "Akun dengan username " . $username . " sudah ada. Silahkan gunakan username lain."];
        } else {
            $sql3 = "INSERT into users(nama_depan, nama_belakang, email, username, password) values(?,?,?,?,?)";
            $stmt3 = $conn->prepare($sql3);
            $stmt3->bind_param("sssss", $nama_depan, $nama_belakang, $email, $username, $password);
            $stmt3->execute();

            if ($stmt3->affected_rows > 0) {
                $arr = ["result" => "success", "message" => "Berhasil melakukan register akun. Silahkan melakukan login."];
            } else {
                $arr = ["result" => "error", "message" => "Terjadi kesalahan. Gagal melakukan register akun."];
            }
        }
    }
}
echo json_encode($arr);
$stmt->close();
$stmt1->close();
$stmt2->close();
$stmt3->close();
$conn->close();
