<?php
header("Access-Control-Allow-Origin: *");
$arr = null;
$conn = new mysqli("localhost", "root", "", "cats");
if ($conn->connect_error) {
    $arr = ["result" => "error", "message" => "unable to connect"];
}

extract($_POST);

$sql = "SELECT B.*, U.username
        FROM beritas as B
        INNER JOIN users as U on U.id = B.user_id
        WHERE B.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();


if ($result->num_rows > 0) {
    if ($r = $result->fetch_assoc()) {
        $sql1 = "SELECT * 
                FROM articles
                where beritas_id = ?
                ORDER BY id ASC";
        $stmt1 = $conn->prepare($sql1);
        $stmt1->bind_param("i", $id);
        $stmt1->execute();
        $result1 = $stmt1->get_result();

        if ($result1->num_rows > 0) {
            $daftarArtikel = [];
            while ($r1 = $result1->fetch_assoc()) {
                array_push($daftarArtikel, $r1);
            }
            $r["articles"] = $daftarArtikel;
            $arr = $r;
        } else {
            $arr = ["result" => "error", "message" => "Tidak terdapat data artikel"];
        }
    }
} else {
    $arr = ["result" => "error", "message" => "Tidak terdapat data berita"];
}
echo json_encode($arr);
$stmt->close();
$conn->close();