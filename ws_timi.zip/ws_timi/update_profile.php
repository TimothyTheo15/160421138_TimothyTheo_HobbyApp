<?php
header("Access-Control-Allow-Origin: *");
$arr = null;
$conn = new mysqli("localhost", "root", "", "cats");
if ($conn->connect_error) {
    $arr = ["result" => "error", "message" => "unable to connect"];
}

extract($_POST);

$sql = "SELECT * FROM users where id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    if ($r = $result->fetch_assoc()) {
        if ($password != "") {
            if ($r["nama_depan"] == $nama_depan && $r["nama_belakang"] == $nama_belakang && $r["password"] == $password) {
                $arr = ["result" => "error", "message" => "Pastikan Anda telah mengubah nama depan, nama belakang, atau password sebelum menyimpan."];
            } else {
                $pesan = [];
                if ($r["nama_depan"] != $nama_depan) {
                    array_push($pesan, "nama_depan = ?");
                }

                if ($r["nama_belakang"] != $nama_belakang) {
                    array_push($pesan, "nama_belakang = ?");
                }

                if ($r["password"] != $password) {
                    array_push($pesan, "password = ?");
                }

                if (count($pesan) == 3) {
                    $updateData = implode(",", $pesan);
                    $sql3 = "UPDATE users SET " . $updateData . " where id=?";
                    $stmt3 = $conn->prepare($sql3);
                    $stmt3->bind_param("sssi", $nama_depan, $nama_belakang, $password, $id);

                } else if (count($pesan) == 2) {
                    $updateData = implode(",", $pesan);
                    $sql3 = "UPDATE users SET " . $updateData . " where id=?";
                    $stmt3 = $conn->prepare($sql3);

                    if ($r["nama_depan"] != $nama_depan && $r["nama_belakang"] != $nama_belakang) {
                        $stmt3->bind_param("ssi", $nama_depan, $nama_belakang, $id);
                    }

                    if ($r["nama_depan"] != $nama_depan && $r["password"] != $password) {
                        $stmt3->bind_param("ssi", $nama_depan, $password, $id);
                    }

                    if ($r["nama_belakang"] != $nama_belakang && $r["password"] != $password) {
                        $stmt3->bind_param("ssi", $nama_belakang, $password, $id);
                    }

                } else {
                    $sql3 = "UPDATE users SET " . $pesan[0] . " where id=?";
                    $stmt3 = $conn->prepare($sql3);

                    if ($r["nama_depan"] != $nama_depan) {
                        $stmt3->bind_param("si", $nama_depan, $id);
                    }

                    if ($r["nama_belakang"] != $nama_belakang) {
                        $stmt3->bind_param("si", $nama_belakang, $id);
                    }

                    if ($r["password"] != $password) {
                        $stmt3->bind_param("si", $password, $id);
                    }
                }

                $stmt3->execute();
                if ($stmt3->affected_rows > 0) {
                    $arr = ["result" => "success", "message" => "Berhasil melakukan update profile"];
                } else {
                    $arr = ["result" => "error", "message" => "Terjadi kesalahan. Gagal melakukan update profile."];
                }
            }
        } else {
            if ($r["nama_depan"] == $nama_depan && $r["nama_belakang"] == $nama_belakang) {
                $arr = ["result" => "error", "message" => "Pastikan Anda telah mengubah nama depan atau nama belakang sebelum menyimpan."];
            } else {
                $pesan = [];
                if ($r["nama_depan"] != $nama_depan) {
                    array_push($pesan, "nama_depan = ?");
                }

                if ($r["nama_belakang"] != $nama_belakang) {
                    array_push($pesan, "nama_belakang = ?");
                }
                if (count($pesan) == 2) {
                    $updateData = implode(",", $pesan);
                    $sql3 = "UPDATE users SET " . $updateData . " where id=?";
                    $stmt3 = $conn->prepare($sql3);

                    if ($r["nama_depan"] != $nama_depan && $r["nama_belakang"] != $nama_belakang) {
                        $stmt3->bind_param("ssi", $nama_depan, $nama_belakang, $id);
                    }
                } else {
                    $sql3 = "UPDATE users SET " . $pesan[0] . " where id=?";
                    $stmt3 = $conn->prepare($sql3);

                    if ($r["nama_depan"] != $nama_depan) {
                        $stmt3->bind_param("si", $nama_depan, $id);
                    }

                    if ($r["nama_belakang"] != $nama_belakang) {
                        $stmt3->bind_param("si", $nama_belakang, $id);
                    }
                }

                $stmt3->execute();
                if ($stmt3->affected_rows > 0) {
                    $arr = ["result" => "success", "message" => "Berhasil melakukan update profile"];
                } else {
                    $arr = ["result" => "error", "message" => "Terjadi kesalahan. Gagal melakukan update profile."];
                }
            }
        }
    }
} else {
    $arr = ["result" => "error", "message" => "User tidak ditemukan"];
}
echo json_encode($arr);
$stmt->close();
$conn->close();
