<?php
header("Access-Control-Allow-Origin: *");
$arr = null;
$conn = new mysqli("localhost", "root", "", "cats");
if ($conn->connect_error) {
    $arr = ["result" => "error", "message" => "unable to connect"];
}


$sql = "SELECT B.id, B.title, B.description, B.photo_url, U.username 
        FROM beritas as B
        INNER JOIN users as U on B.user_id = U.id
        ORDER BY B.id DESC";
$result = $conn->query($sql);

$data = [];

if ($result->num_rows > 0) {
    while ($r = $result->fetch_assoc()) {
        array_push($data, $r);
    }
    $arr = $data;
} else {
    $arr = ["result" => "error", "message" => "sql error: $sql"];
}
echo json_encode($arr);
$conn->close();
